package main;

import mainFrame.MainFrame;

public class Main {

	public static void main(String[] args) {
		new MainFrame();
	}

}
